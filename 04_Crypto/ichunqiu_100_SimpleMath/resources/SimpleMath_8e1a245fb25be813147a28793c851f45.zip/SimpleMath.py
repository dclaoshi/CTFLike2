from Crypto.Util.number import *
from hashlib import md5

flag = "xxx"
assert len(flag) == 15
pad = bytes_to_long(md5(flag).digest())

hack = 0

for char in flag:
	hack *= ord(char)
	hack += pad
	
print hack
# hack = 280098481791453837177137197730537158171743673148935867304957882116
# flag = "flag{" + flag + "}"